
const sheetID = "1yW2olXk66-gKftSdJqj6coQxZYNd8LrMhVDln-Kx9U0";
const base = `https://docs.google.com/spreadsheets/d/${sheetID}/gviz/tq?`;
const query = encodeURIComponent("Select A, B, C, D");
const url = `${base}&tq=${query}`;

fetch(url)
  .then(res => res.text())
  .then(rep => {
    const data = JSON.parse(rep.substr(47).slice(0, -2));
    const rows = data.table.rows;
    const tbody = document.getElementById("scoreTableBody");
    tbody.innerHTML = "";
    rows.forEach(row => {
      const tr = document.createElement("tr");
      row.c.forEach(cell => {
        const td = document.createElement("td");
        td.textContent = cell ? cell.v : "";
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    });
  })
  .catch(err => {
    document.getElementById("scoreTableBody").innerHTML =
      "<tr><td colspan='4'>Failed to load scores.</td></tr>";
    console.error("Fetch error:", err);
  });
